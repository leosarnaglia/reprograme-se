////////////////MÓDULOS /////////////////////
const express = require("express");
const router = express.Router();
//////CONTROLLERS
const funcionarioController = require("../controller/funcionarioController");
const livrosController = require("../controller/livrosController");
////////////////Requisições HTTP Principal /////////////////////
router.get("/", (req, res) => {
  return res.json({ message: "Biblioteca" });
});
////////////////Requisições HTTP Funcionario /////////////////////
//POST - CADASTRAR
router.post("/add_funcionario", funcionarioController.FuncionarioCreate);
//GET - LISTAR
router.get(
  "/funcionario/:id?",
  funcionarioController.verificaJWT,
  funcionarioController.FuncionarioListar,
);
//PUT - UPDATE
router.put("/funcionarios/:id", funcionarioController.FuncionarioUpdate);
// DELETE
router.delete("/funcionarios/:id", funcionarioController.FuncionarioDelete);

//Rotas para as funções
router.post("/login", funcionarioController.FuncionarioVerificaLogin);

////////////////REQUISIÇÕES PRODUTO /////////////////////
//POST - CADASTRAR
router.post("/add_livro", livrosController.LivroCreate);

//GET - LISTAR
router.get("/livros/:id?", livrosController.LivroListar);

module.exports = router;
